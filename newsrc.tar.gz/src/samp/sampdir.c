#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <utime.h>
#include <malloc.h>
#include <inttypes.h>
#include <db.h>
#include <mangooapp.h>
#include <mangoostore.h>
#include "../stores/dbfs/dbfs.h"

static struct mangoo_store *ms;
struct mangoo_handle *handle = NULL;
char *path="/newdir";
int error;

struct my_dir
{
  struct mangoo_handle *handle;
  off_t cur_off;
  off_t starting_off;
  char *saved_name;
  off_t saved_off;
  enum mangoo_types saved_type;
  void *buf;
};


int my_filler(void *fhandle,const char *name,enum mangoo_types type)
{
  struct my_dir *dir = (struct my_dir*)fhandle;
  printf("OPEN MY_FILLER..!!!\n");
  printf("my_filler: %s %d\n",name,(int)type);
  return dir->cur_off++;
}

int main()
{
  int err;
  off_t size;
  size_t sz;
  mode_t mode = 0x81B4;
  enum mangoo_types mt;
  char *url="dbfs\0";
  char *rl="/tmp/dbfs_vol\0";
  off_t offset=0;
  DB_ENV *dbenv;
  struct my_dir *dir;
  void *buf;
  if(err=mangoo_initstore(url,rl,&ms))
    printf("Error in store\n");
  else
    printf("store opened\n");
  if(err=mangoo_open(ms,path,mangoo_stream_interface,&handle))
    {
      printf("Error Opening %d\n",err);
    }
  else
    {
      printf("OPEN\n");
      //env_open(&dbenv);
      offset=0;
      dir=(struct mf_dir *)handle;
      dir->handle=handle;
      /*dir->saved_name=path;
      mattr_gettype(handle,&mt);
      dir->saved_type=mt;*/
      printf("Read directory\n");
      if(dir->saved_name)
	{
	  printf("First If\n");
	  my_filler(dir,dir->saved_name,dir->saved_type);
	  offset++;
	  //free(dir->saved_name);
	  dir->saved_name=NULL;
	}
	dir->starting_off=offset;
	printf("Mdir_read starts\n");
      error = mdir_read(dir->handle,my_filler,dir);
      if(error == ENOBUFS)
	printf("Error occurred..!!\n");
      printf("saved name %s",dir->saved_name);
      printf("error number %d\n",error);
      (void)mangoo_close(handle);
    }
  mangoo_closestore(ms);
return 0;
}
