#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <utime.h>
#include <malloc.h>
#include <inttypes.h>
#include <db.h>

#include <mangooapp.h>
#include <mangoostore.h>
#include "../stores/dbfs/dbfs.h"

static struct mangoo_store *ms;
struct mangoo_handle *handle = NULL;
struct dbfs_handle *dh;

void env_dir_create()
{
  struct stat sb;
  char *path="/tmp/TXNAPP";

  /*
   * If the directory exists, we're done.  We do not further check
   * the type of the file, DB will fail appropriately if it's the
   * wrong type.
   */
  if(stat(path, &sb) == 0)
    return;


  /* Create the directory, read/write/access owner only. */
  if(mkdir(path, S_IRWXU) != 0) {
    fprintf(stderr,
	    "txnapp: mkdir: %s: %s\n", path, strerror(errno));
    exit (1);
  }
}


void sampwrite(char *path,char *buf,size_t *sz,off_t *offset)
{
  int err;
  mode_t mode=0x81B4;
 back:
  if(err=mangoo_open(ms,path,mangoo_stream_interface,&handle))
    {
      printf("ERROR %d\n",err);
      if(err=mangoo_create(ms,path,mode,mangoo_data))
	printf("Error creating\n");
      else
	{
	  printf("File created\n");
	  goto back;
	}
    }
  else
    {
      printf("OPEN\n");
      dh = (struct dbfs_handle*)handle;
      printf("Size : %jd\n ",(intmax_t)(dh->attr_ddd.ddd_size));
      printf("Mode : %o\n ",(dh->attr_ddd.ddd_mode));
      *sz=strlen(buf)+1;
      if(err=mstream_write(handle,buf,sz,*offset))
	printf("Error while writing buf : %d\n",err);
      else
	*offset+=strlen(buf);      
      (void)mangoo_close(handle);
    }
}

void sampread(char *path)
{
  off_t offset=0;
  size_t sz;
  char buffer[30];
  int err;
  if(err=mangoo_open(ms,path,mangoo_stream_interface,&handle))
    {
      printf("Error Opening %d\n",err);
    }
  else
    {
      printf("OPEN\n");
      dh = (struct dbfs_handle*)handle;
      printf("Size : %jd\n ",(intmax_t)(dh->attr_ddd.ddd_size));
      printf("Mode : %o\n ",(dh->attr_ddd.ddd_mode));
      offset=0;
      sz=(size_t)(dh->attr_ddd.ddd_size);
      if(err=mstream_read(handle,buffer,&sz,offset))
	printf("Error while reading %d\n",err);
      else
	printf("%s\n",buffer);
      (void)mangoo_close(handle);
    }

}

void help()
{
  printf("1: write\n");
  printf("Write data to any file.\n");
  printf("Syntax: write data_to_enter file_name\n\n");
  printf("2: read\n");
  printf("Rread data from any file.\n");
  printf("Syntax: read file_name\n\n");
  printf("3: exit\n");
  printf("Exit the mangoostore.\n\n");
  printf("4: help\n");
  printf("Displays the commands help.\n\n");
}

int main()
{
  int err;
  off_t size;
  size_t sz;
  mode_t mode = 0x81B4;
  char *path,*buf,buffer[30];
  char *url="dbfs\0";
  char *rl="/tmp/dbfs_vol\0";
  char input[100],tok1[20],tok2[20],tok3[20];
  off_t offset=0;
  DB_ENV *dbenv;
  if(err=mangoo_initstore(url,rl,&ms))
    printf("Error in store\n");
  else
    printf("store opened\n");
  while(1)
    {
      scanf("%[^\n]%*c",input);
      sscanf(input,"%s%s%s",tok1,tok2,tok3);
      env_dir_create();
      if(!strcmp(tok1,"write"))
	{
	  path=tok3;
	  buf=tok2;
	  env_open(&dbenv);
	  sampwrite(path,buf,&sz,&offset);
	  (void)dbenv->close(dbenv,0);
	}
      else if(!strcmp(tok1,"read"))
	{
	  path=tok2;
	  env_open(&dbenv);
	  sampread(path);
	  (void)dbenv->close(dbenv,0);
	}
      else if(!strcmp(tok1,"exit"))
	{
	  mangoo_closestore(ms);
	  exit(0);
	}
      else if(!strcmp(tok1,"help"))
	{
	  help();
	}
      else{
	printf("Command Not Found! Enter help to know working commands\n");
      }
    }
  return 0;
}
